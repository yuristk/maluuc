
import React from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ExerciseCard from '@/components/ExerciseModule/ExerciseCard';

const Exercises: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-3">{t('exercises')}</h1>
        <p className="text-muted-foreground">
          Follow guided exercises and breathing techniques to enhance your results.
        </p>
      </div>
      
      <Tabs defaultValue="kegel" className="w-full">
        <TabsList className="w-full flex justify-start mb-6 overflow-x-auto">
          <TabsTrigger value="kegel">Kegel Exercises</TabsTrigger>
          <TabsTrigger value="breathing">Breathing Techniques</TabsTrigger>
          <TabsTrigger value="mobility">Mobility & Stretching</TabsTrigger>
          <TabsTrigger value="challenges">Challenges</TabsTrigger>
        </TabsList>
        
        <TabsContent value="kegel" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ExerciseCard 
              title="Basic Kegel Routine"
              description="Strengthen your pelvic floor muscles with this basic routine"
              duration="5-10 minutes"
              imageUrl="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
            <ExerciseCard 
              title="Advanced Kegel Series"
              description="Take your pelvic floor strength to the next level"
              duration="10-15 minutes"
              imageUrl="https://images.unsplash.com/photo-1518611012118-696072aa579a?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
            <ExerciseCard 
              title="Custom Kegel Program"
              description="A personalized routine based on your progress"
              duration="15-20 minutes"
              imageUrl="https://images.unsplash.com/photo-1594737625785-a6cbdabd333c?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="breathing" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ExerciseCard 
              title="Deep Breathing"
              description="Reduce anxiety and improve blood flow with guided breathing"
              duration="3-5 minutes"
              imageUrl="https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
            <ExerciseCard 
              title="Box Breathing"
              description="Master the technique used by elite performers to stay calm under pressure"
              duration="5-8 minutes"
              imageUrl="https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="mobility" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ExerciseCard 
              title="Hip Mobility"
              description="Improve circulation and flexibility with hip mobility exercises"
              duration="7-10 minutes"
              imageUrl="https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="challenges" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ExerciseCard 
              title="5-Day Challenge"
              description="Complete all exercises for 5 consecutive days"
              duration="5 days"
              imageUrl="https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=800&auto=format&fit=crop"
              onClick={() => {}}
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Exercises;
