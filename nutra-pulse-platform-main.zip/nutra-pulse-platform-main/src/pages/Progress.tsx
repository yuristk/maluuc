
import React from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ProgressChart from '@/components/ProgressModule/ProgressChart';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Sample progress data
const wellbeingData = [
  { date: 'Week 1', value: 2 },
  { date: 'Week 2', value: 2.5 },
  { date: 'Week 3', value: 3 },
  { date: 'Week 4', value: 2.8 },
  { date: 'Week 5', value: 3.2 },
  { date: 'Week 6', value: 3.6 },
  { date: 'Week 7', value: 4 },
];

const improvementData = [
  { date: 'Week 1', value: 1 },
  { date: 'Week 2', value: 1.5 },
  { date: 'Week 3', value: 2.1 },
  { date: 'Week 4', value: 2.3 },
  { date: 'Week 5', value: 2.8 },
  { date: 'Week 6', value: 3.4 },
  { date: 'Week 7', value: 3.7 },
];

const usageData = [
  { date: 'Week 1', value: 6 },
  { date: 'Week 2', value: 7 },
  { date: 'Week 3', value: 6 },
  { date: 'Week 4', value: 5 },
  { date: 'Week 5', value: 7 },
  { date: 'Week 6', value: 6 },
  { date: 'Week 7', value: 7 },
];

const Progress: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-3">{t('progress')}</h1>
        <p className="text-muted-foreground">
          Track your results and monitor your progress over time.
        </p>
      </div>
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-semibold">Cycle</h2>
          <Select defaultValue="current">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select cycle" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Current Cycle</SelectItem>
              <SelectItem value="previous">Previous Cycle</SelectItem>
              <SelectItem value="compare">Compare Cycles</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className="text-sm text-muted-foreground">Day 23 of 30</span>
          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
            <div className="bg-primary h-full rounded-full" style={{ width: '76%' }}></div>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="w-full flex justify-start mb-6 overflow-x-auto">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="assessments">Self-Assessments</TabsTrigger>
          <TabsTrigger value="comparison">Cycle Comparison</TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ProgressChart 
              title="Well-being Score"
              description="Track your daily well-being on a scale from 1-5"
              data={wellbeingData}
            />
            
            <ProgressChart 
              title="Improvement Perception"
              description="Your reported improvement over time"
              data={improvementData}
              color="hsl(var(--accent))"
            />
            
            <ProgressChart 
              title="Usage Consistency"
              description="Days per week you've taken your supplement"
              data={usageData}
              color="hsl(var(--primary))"
            />
            
            <Card>
              <CardHeader>
                <CardTitle>Activity Summary</CardTitle>
                <CardDescription>Your engagement with the program</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <ActivityItem 
                    label="Capsules Taken" 
                    value="21/23"
                    percentage={91}
                  />
                  <ActivityItem 
                    label="Exercises Completed" 
                    value="8/12"
                    percentage={67}
                  />
                  <ActivityItem 
                    label="Articles Read" 
                    value="5/15"
                    percentage={33}
                  />
                  <ActivityItem 
                    label="Daily Feedback Submitted" 
                    value="18/23"
                    percentage={78}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="assessments" className="space-y-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-medium mb-4">Bi-Weekly Assessment</h3>
            <p className="text-muted-foreground mb-6">
              Complete this assessment every two weeks to track your progress over time.
            </p>
            
            <div className="space-y-8">
              <AssessmentQuestion 
                question="How would you rate your overall energy levels?" 
                options={["Very Low", "Low", "Moderate", "High", "Very High"]}
              />
              <AssessmentQuestion 
                question="How would you rate your confidence in intimate situations?" 
                options={["Very Low", "Low", "Moderate", "High", "Very High"]}
              />
              <AssessmentQuestion 
                question="How satisfied are you with your performance?" 
                options={["Very Dissatisfied", "Dissatisfied", "Neutral", "Satisfied", "Very Satisfied"]}
              />
              <AssessmentQuestion 
                question="Have you noticed improvement in maintaining erections?" 
                options={["None", "Slight", "Moderate", "Significant", "Major"]}
              />
              
              <div className="pt-4 flex justify-end">
                <button className="bg-primary text-white px-6 py-2 rounded-md">
                  Submit Assessment
                </button>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="comparison" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Cycle Comparison</CardTitle>
                <CardDescription>Compare your results between different cycles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex justify-between">
                    <Select defaultValue="cycle1">
                      <SelectTrigger className="w-[140px]">
                        <SelectValue placeholder="Cycle 1" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cycle1">Cycle 1</SelectItem>
                        <SelectItem value="cycle2">Cycle 2</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <div className="flex items-center">
                      <span className="mr-2">vs</span>
                      <Select defaultValue="cycle2">
                        <SelectTrigger className="w-[140px]">
                          <SelectValue placeholder="Cycle 2" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cycle1">Cycle 1</SelectItem>
                          <SelectItem value="cycle2">Cycle 2</SelectItem>
                          <SelectItem value="cycle3">Current Cycle</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-4 pt-4">
                    <ComparisonItem 
                      label="Average Well-being" 
                      value1="3.2/5"
                      value2="4.1/5"
                      improved={true}
                    />
                    <ComparisonItem 
                      label="Consistency" 
                      value1="85%"
                      value2="91%"
                      improved={true}
                    />
                    <ComparisonItem 
                      label="Exercise Completion" 
                      value1="72%"
                      value2="67%"
                      improved={false}
                    />
                    <ComparisonItem 
                      label="Reported Improvement" 
                      value1="2.8/5"
                      value2="3.7/5"
                      improved={true}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface ActivityItemProps {
  label: string;
  value: string;
  percentage: number;
}

const ActivityItem: React.FC<ActivityItemProps> = ({ label, value, percentage }) => {
  return (
    <div className="space-y-2">
      <div className="flex justify-between">
        <span className="text-sm font-medium">{label}</span>
        <span className="text-sm font-medium">{value}</span>
      </div>
      <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className="bg-primary h-full rounded-full transition-all duration-500" 
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

interface AssessmentQuestionProps {
  question: string;
  options: string[];
}

const AssessmentQuestion: React.FC<AssessmentQuestionProps> = ({ question, options }) => {
  return (
    <div className="space-y-3">
      <h4 className="font-medium">{question}</h4>
      <div className="grid grid-cols-5 gap-2">
        {options.map((option, index) => (
          <div 
            key={index}
            className="border rounded-md p-2 text-center text-sm cursor-pointer hover:bg-primary/10 transition-colors"
          >
            {option}
          </div>
        ))}
      </div>
    </div>
  );
};

interface ComparisonItemProps {
  label: string;
  value1: string;
  value2: string;
  improved: boolean;
}

const ComparisonItem: React.FC<ComparisonItemProps> = ({ label, value1, value2, improved }) => {
  return (
    <div className="flex items-center justify-between p-3 border rounded-md">
      <span className="font-medium">{label}</span>
      <div className="flex items-center gap-3">
        <span className="text-muted-foreground">{value1}</span>
        <span className="text-lg">→</span>
        <span className={improved ? "text-green-600 font-medium" : "text-red-600 font-medium"}>
          {value2}
        </span>
      </div>
    </div>
  );
};

export default Progress;
