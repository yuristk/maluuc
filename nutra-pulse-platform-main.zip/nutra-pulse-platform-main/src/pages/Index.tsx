
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, Dumbbell, BookOpen, LineChart, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/context/LanguageContext';
import { useToast } from "@/hooks/use-toast";

// Module components
import UsageCalendar from '@/components/UsageModule/UsageCalendar';
import ExerciseCard from '@/components/ExerciseModule/ExerciseCard';
import ArticlePreview from '@/components/ContentModule/ArticlePreview';
import ProgressChart from '@/components/ProgressModule/ProgressChart';

const SectionTitle: React.FC<{ 
  icon: React.ReactNode; 
  title: string; 
  action?: React.ReactNode 
}> = ({ icon, title, action }) => (
  <div className="flex items-center justify-between mb-4">
    <div className="flex items-center gap-2">
      {icon}
      <h2 className="text-xl font-semibold">{title}</h2>
    </div>
    {action}
  </div>
);

// Sample progress data
const progressData = [
  { date: 'Week 1', value: 2 },
  { date: 'Week 2', value: 2.5 },
  { date: 'Week 3', value: 3 },
  { date: 'Week 4', value: 2.8 },
  { date: 'Week 5', value: 3.2 },
  { date: 'Week 6', value: 3.6 },
  { date: 'Week 7', value: 4 },
];

const Index: React.FC = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const handleExerciseClick = (title: string) => {
    toast({
      title: "Exercise Selected",
      description: `You've selected: ${title}`,
    });
    navigate('/exercises');
  };
  
  const handleArticleClick = (title: string) => {
    toast({
      title: "Article Selected",
      description: `You've selected: ${title}`,
    });
    navigate('/content');
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl sm:text-4xl font-bold mb-3 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/70">
          {t('appName')} Platform
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Track your progress, optimize your usage, and enhance your results with personalized guidance.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        <ModuleCard 
          icon={<Calendar className="h-6 w-6" />}
          title={t('usage')}
          description="Track your daily usage and optimize your protocol"
          onClick={() => navigate('/usage')}
        />
        <ModuleCard 
          icon={<Dumbbell className="h-6 w-6" />}
          title={t('exercises')}
          description="Follow guided exercises and breathing techniques"
          onClick={() => navigate('/exercises')}
        />
        <ModuleCard 
          icon={<BookOpen className="h-6 w-6" />}
          title={t('content')}
          description="Access exclusive educational content and resources"
          onClick={() => navigate('/content')}
        />
        <ModuleCard 
          icon={<LineChart className="h-6 w-6" />}
          title={t('progress')}
          description="Monitor your progress and track your results"
          onClick={() => navigate('/progress')}
        />
      </div>
      
      <div className="space-y-12">
        {/* Usage Section */}
        <section>
          <SectionTitle 
            icon={<Calendar className="h-5 w-5 text-primary" />}
            title={t('usageCalendar')}
            action={
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/usage')}
                className="group"
              >
                View All
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            }
          />
          <UsageCalendar />
        </section>
        
        {/* Exercise Section */}
        <section>
          <SectionTitle 
            icon={<Dumbbell className="h-5 w-5 text-primary" />}
            title={t('exerciseLibrary')}
            action={
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/exercises')}
                className="group"
              >
                View All
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            }
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ExerciseCard 
              title="Basic Kegel Routine"
              description="Strengthen your pelvic floor muscles with this basic routine"
              duration="5-10 minutes"
              imageUrl="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&auto=format&fit=crop"
              onClick={() => handleExerciseClick("Basic Kegel Routine")}
            />
            <ExerciseCard 
              title="Deep Breathing"
              description="Reduce anxiety and improve blood flow with guided breathing"
              duration="3-5 minutes"
              imageUrl="https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&auto=format&fit=crop"
              onClick={() => handleExerciseClick("Deep Breathing")}
            />
            <ExerciseCard 
              title="Hip Mobility"
              description="Improve circulation and flexibility with hip mobility exercises"
              duration="7-10 minutes"
              imageUrl="https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=800&auto=format&fit=crop"
              onClick={() => handleExerciseClick("Hip Mobility")}
              completed={true}
            />
          </div>
        </section>
        
        {/* Content Section */}
        <section>
          <SectionTitle 
            icon={<BookOpen className="h-5 w-5 text-primary" />}
            title={t('articles')}
            action={
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/content')}
                className="group"
              >
                View All
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            }
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ArticlePreview 
              title="Understanding Male Health Fundamentals"
              description="Learn about the key factors that influence male sexual health and how to address common concerns naturally."
              category="Education"
              readTime="5"
              imageUrl="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop"
              onClick={() => handleArticleClick("Understanding Male Health Fundamentals")}
            />
            <ArticlePreview 
              title="Nutrition & Supplements Guide"
              description="Discover the essential nutrients and supplements that can enhance your sexual health and overall wellbeing."
              category="Nutrition"
              readTime="7"
              imageUrl="https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&auto=format&fit=crop"
              onClick={() => handleArticleClick("Nutrition & Supplements Guide")}
            />
            <ArticlePreview 
              title="Building Confidence in Intimacy"
              description="Practical techniques and mental approaches to building confidence and improving your intimate relationships."
              category="Relationships"
              readTime="6"
              imageUrl="https://images.unsplash.com/photo-1516401266446-6432a8a07d41?w=800&auto=format&fit=crop"
              onClick={() => handleArticleClick("Building Confidence in Intimacy")}
            />
          </div>
        </section>
        
        {/* Progress Section */}
        <section>
          <SectionTitle 
            icon={<LineChart className="h-5 w-5 text-primary" />}
            title={t('progressDashboard')}
            action={
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/progress')}
                className="group"
              >
                View All
                <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            }
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ProgressChart 
              title="Well-being Score"
              description="Track your daily well-being on a scale from 1-5"
              data={progressData}
            />
            <ProgressChart 
              title="Improvement Perception"
              description="Your reported improvement over time"
              data={progressData.map((item, i) => ({ 
                date: item.date, 
                value: Math.min(i * 0.6 + 1, 5) 
              }))}
              color="hsl(var(--accent))"
            />
          </div>
        </section>
      </div>
    </div>
  );
};

interface ModuleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}

const ModuleCard: React.FC<ModuleCardProps> = ({ icon, title, description, onClick }) => {
  return (
    <Card 
      className="glass-card h-full transition-all duration-300 hover:shadow-md hover:translate-y-[-2px] cursor-pointer group"
      onClick={onClick}
    >
      <CardContent className="p-6 flex flex-col h-full">
        <div className="rounded-full bg-primary/10 p-3 w-fit mb-4 group-hover:bg-primary/20 transition-colors">
          <div className="text-primary">
            {icon}
          </div>
        </div>
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

export default Index;
