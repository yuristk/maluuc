
import React, { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ArticlePreview from '@/components/ContentModule/ArticlePreview';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Article, ForumThread, ForumReply } from '@/components/UsageModule/UsageTypes';
import { MessageSquare, User, Award, Clock, ArrowLeft, MessageCircle, Bookmark, Heart } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

// Sample pre-loaded articles for English
const englishArticles: Article[] = [
  {
    id: "1",
    title: "Understanding Male Health Fundamentals",
    description: "Learn about the key factors that influence male sexual health and how to address common concerns naturally.",
    content: `
      <h2>The Foundations of Male Sexual Health</h2>
      
      <p>Male sexual health is influenced by a complex interplay of physical, psychological, and social factors. Understanding these components is crucial for maintaining overall well-being and addressing concerns effectively.</p>
      
      <h3>Physical Factors</h3>
      
      <p>Several physiological processes contribute to healthy sexual function:</p>
      
      <ul>
        <li><strong>Hormonal Balance:</strong> Testosterone plays a crucial role in libido, erectile function, and overall energy levels.</li>
        <li><strong>Cardiovascular Health:</strong> Good blood flow is essential for sexual function, making heart health a priority.</li>
        <li><strong>Neurological Function:</strong> The nervous system coordinates arousal and physical responses during sexual activity.</li>
      </ul>
      
      <h3>Psychological Considerations</h3>
      
      <p>Mental well-being significantly impacts sexual health:</p>
      
      <ul>
        <li><strong>Stress Management:</strong> Chronic stress can deplete energy and reduce sexual desire.</li>
        <li><strong>Anxiety and Depression:</strong> These conditions often correlate with sexual dysfunction.</li>
        <li><strong>Body Image:</strong> How men perceive themselves can affect confidence and performance.</li>
      </ul>
      
      <h3>Natural Approaches to Enhancement</h3>
      
      <p>Several evidence-based natural approaches can support male sexual health:</p>
      
      <ul>
        <li><strong>Nutrition:</strong> A diet rich in antioxidants, healthy fats, and specific nutrients can improve sexual function.</li>
        <li><strong>Regular Exercise:</strong> Physical activity improves blood flow, hormone balance, and confidence.</li>
        <li><strong>Quality Sleep:</strong> Sleep optimization directly impacts testosterone production and energy levels.</li>
        <li><strong>Stress Reduction:</strong> Techniques like mindfulness and meditation can minimize the impact of stress.</li>
      </ul>
      
      <h3>When to Seek Professional Help</h3>
      
      <p>While many aspects of sexual health can be addressed through lifestyle changes, certain situations require medical attention:</p>
      
      <ul>
        <li>Persistent erectile difficulties</li>
        <li>Significant changes in libido</li>
        <li>Physical pain during arousal or intercourse</li>
        <li>Concerns about fertility</li>
      </ul>
      
      <p>Remember that sexual health concerns are common and treatable. Open communication with healthcare providers is essential for addressing issues effectively.</p>
    `,
    category: "Education",
    readTime: "5",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop",
    language: "en"
  },
  {
    id: "2",
    title: "Nutrition & Supplements Guide",
    description: "Discover the essential nutrients and supplements that can enhance your sexual health and overall wellbeing.",
    content: `
      <h2>Optimizing Nutrition for Sexual Health</h2>
      
      <p>What you eat has a direct impact on your sexual health and performance. This guide explores the key nutrients and supplements that can make a significant difference.</p>
      
      <h3>Key Nutrients for Male Sexual Function</h3>
      
      <ul>
        <li><strong>Zinc:</strong> Essential for testosterone production and sperm health. Found in oysters, pumpkin seeds, and beef.</li>
        <li><strong>L-arginine:</strong> An amino acid that improves blood flow by increasing nitric oxide production. Found in turkey, chicken, and pumpkin seeds.</li>
        <li><strong>Vitamin D:</strong> Linked to testosterone production and overall vitality. Primary source is sunlight, but also found in fatty fish and fortified foods.</li>
        <li><strong>Omega-3 Fatty Acids:</strong> Support cardiovascular health and blood flow. Found in fatty fish, flaxseeds, and walnuts.</li>
      </ul>
      
      <h3>Dietary Patterns for Optimal Performance</h3>
      
      <p>Research suggests that the following dietary approaches can benefit sexual health:</p>
      
      <ul>
        <li><strong>Mediterranean Diet:</strong> Rich in vegetables, fruits, whole grains, lean proteins, and healthy fats. Associated with lower rates of erectile dysfunction.</li>
        <li><strong>Anti-inflammatory Foods:</strong> Berries, leafy greens, fatty fish, and nuts can reduce inflammation that contributes to sexual dysfunction.</li>
        <li><strong>Hydration:</strong> Proper fluid intake supports circulation and overall physical function.</li>
      </ul>
      
      <h3>Supplements with Scientific Support</h3>
      
      <p>While whole foods should be your primary source of nutrition, certain supplements have shown promise for supporting male sexual health:</p>
      
      <ul>
        <li><strong>Maca Root:</strong> Traditionally used to enhance libido and stamina.</li>
        <li><strong>Panax Ginseng:</strong> May improve erectile function and sexual satisfaction.</li>
        <li><strong>Ashwagandha:</strong> Can help reduce stress and potentially increase testosterone levels.</li>
        <li><strong>Fenugreek:</strong> Some studies suggest it may support healthy testosterone levels.</li>
      </ul>
      
      <h3>Foods to Limit or Avoid</h3>
      
      <p>Certain dietary choices can negatively impact sexual health:</p>
      
      <ul>
        <li><strong>Excessive Alcohol:</strong> Can reduce testosterone and impair sexual function.</li>
        <li><strong>Processed Foods:</strong> High in inflammatory compounds that may affect circulation.</li>
        <li><strong>Added Sugars:</strong> Can contribute to conditions that impair sexual health, like diabetes and obesity.</li>
        <li><strong>Trans Fats:</strong> May damage blood vessels and impair circulation.</li>
      </ul>
      
      <h3>Creating a Sustainable Nutrition Plan</h3>
      
      <p>The best nutrition strategy is one you can maintain long-term:</p>
      
      <ul>
        <li>Focus on whole, minimally processed foods.</li>
        <li>Ensure adequate protein intake for hormone production.</li>
        <li>Include a variety of colorful fruits and vegetables.</li>
        <li>Stay hydrated throughout the day.</li>
        <li>Consider working with a nutritionist for personalized guidance.</li>
      </ul>
      
      <p>Remember that nutrition is just one piece of the puzzle. Combine these dietary strategies with regular exercise, stress management, and quality sleep for optimal results.</p>
    `,
    category: "Nutrition",
    readTime: "7",
    imageUrl: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&auto=format&fit=crop",
    language: "en"
  },
  {
    id: "3",
    title: "Sleep & Recovery Optimization",
    description: "How quality sleep directly impacts your hormone production and sexual health.",
    content: `
      <h2>The Critical Connection Between Sleep and Sexual Health</h2>
      
      <p>Quality sleep is a fundamental pillar of sexual health that is often overlooked. This article explores how sleep affects hormone production, energy levels, and overall sexual function.</p>
      
      <h3>Sleep and Hormone Regulation</h3>
      
      <p>Sleep plays a crucial role in hormonal balance:</p>
      
      <ul>
        <li><strong>Testosterone Production:</strong> The majority of daily testosterone release occurs during REM sleep. Insufficient sleep can lower testosterone levels by 10-15%.</li>
        <li><strong>Cortisol Management:</strong> Poor sleep increases cortisol (stress hormone), which can inhibit sexual function and reduce libido.</li>
        <li><strong>Growth Hormone:</strong> This important recovery hormone is primarily released during deep sleep phases.</li>
      </ul>
      
      <h3>How Sleep Deprivation Affects Sexual Health</h3>
      
      <p>Research has identified several ways that inadequate sleep impacts sexual wellness:</p>
      
      <ul>
        <li><strong>Reduced Desire:</strong> Sleep-deprived individuals report lower levels of sexual interest and arousal.</li>
        <li><strong>Erectile Function:</strong> Studies show a correlation between sleep disorders like sleep apnea and erectile difficulties.</li>
        <li><strong>Energy and Stamina:</strong> Poor sleep diminishes physical energy reserves needed for satisfying sexual activity.</li>
        <li><strong>Mood Regulation:</strong> Sleep deprivation increases irritability and decreases positive mood states that support intimacy.</li>
      </ul>
      
      <h3>Optimizing Your Sleep for Sexual Health</h3>
      
      <p>Implement these evidence-based strategies to improve your sleep quality:</p>
      
      <ul>
        <li><strong>Consistent Schedule:</strong> Go to bed and wake up at the same times each day, even on weekends.</li>
        <li><strong>Sleep Environment:</strong> Keep your bedroom cool (65-68°F/18-20°C), dark, and quiet.</li>
        <li><strong>Digital Sunset:</strong> Avoid screens 1-2 hours before bedtime to support natural melatonin production.</li>
        <li><strong>Relaxation Routine:</strong> Develop a pre-sleep ritual that signals to your body it's time to wind down.</li>
        <li><strong>Nutrition Timing:</strong> Avoid large meals, caffeine, and alcohol close to bedtime.</li>
      </ul>
      
      <h3>Natural Sleep-Supporting Supplements</h3>
      
      <p>Consider these evidence-supported options if you struggle with sleep:</p>
      
      <ul>
        <li><strong>Magnesium:</strong> Promotes relaxation and sleep quality. Found in dark chocolate, nuts, and leafy greens.</li>
        <li><strong>Melatonin:</strong> May help reset sleep cycles when used appropriately.</li>
        <li><strong>L-theanine:</strong> An amino acid found in tea that promotes relaxation without drowsiness.</li>
        <li><strong>Valerian Root:</strong> Traditional herb used to improve sleep quality.</li>
      </ul>
      
      <h3>When to Seek Professional Help</h3>
      
      <p>Consider consulting a healthcare provider if you experience:</p>
      
      <ul>
        <li>Persistent insomnia despite good sleep hygiene practices</li>
        <li>Snoring accompanied by gasping or choking (possible sleep apnea)</li>
        <li>Excessive daytime sleepiness</li>
        <li>Restless legs or periodic limb movements that disrupt sleep</li>
      </ul>
      
      <p>Remember that investing in your sleep quality is investing in your sexual health and overall wellbeing. Make sleep a priority, and you'll likely see improvements in multiple aspects of your life.</p>
    `,
    category: "Lifestyle",
    readTime: "6",
    imageUrl: "https://images.unsplash.com/photo-1519003300449-424ad0405076?w=800&auto=format&fit=crop",
    language: "en"
  },
  {
    id: "4",
    title: "Building Confidence in Intimacy",
    description: "Practical techniques and mental approaches to building confidence and improving your intimate relationships.",
    content: `
      <h2>Building Authentic Confidence in Intimate Relationships</h2>
      
      <p>Confidence in intimate settings isn't just about performance—it's about creating genuine connection, comfort, and mutual satisfaction. This guide offers practical strategies to develop lasting confidence.</p>
      
      <h3>Understanding the Psychology of Confidence</h3>
      
      <p>True confidence in intimacy comes from:</p>
      
      <ul>
        <li><strong>Self-Acceptance:</strong> Recognizing that perfection is a myth and embracing your authentic self.</li>
        <li><strong>Mindfulness:</strong> Being fully present rather than caught in performance anxiety or distraction.</li>
        <li><strong>Resilience:</strong> The ability to navigate challenges without excessive self-criticism.</li>
        <li><strong>Knowledge:</strong> Understanding your own body, preferences, and responses.</li>
      </ul>
      
      <h3>Practical Confidence-Building Techniques</h3>
      
      <ul>
        <li><strong>Body Awareness Practices:</strong>
          <ul>
            <li>Regular exercise that builds connection with your body</li>
            <li>Mindfulness meditation to reduce performance anxiety</li>
            <li>Progressive muscle relaxation to release physical tension</li>
          </ul>
        </li>
        <li><strong>Cognitive Approaches:</strong>
          <ul>
            <li>Identifying and challenging negative self-talk</li>
            <li>Replacing catastrophic thinking with realistic perspectives</li>
            <li>Focusing on pleasure and connection rather than performance</li>
          </ul>
        </li>
        <li><strong>Skill Development:</strong>
          <ul>
            <li>Learning about intimate communication</li>
            <li>Understanding your partner's preferences</li>
            <li>Developing comfort with giving and receiving feedback</li>
          </ul>
        </li>
      </ul>
      
      <h3>Communication: The Foundation of Intimate Confidence</h3>
      
      <p>Effective communication is essential for building confidence:</p>
      
      <ul>
        <li><strong>Before Intimacy:</strong> Discuss preferences, boundaries, and desires in a non-pressured setting.</li>
        <li><strong>During Intimate Moments:</strong> Use verbal and non-verbal cues to guide and respond to your partner.</li>
        <li><strong>After Sharing Intimacy:</strong> Reflect on the experience with openness and without judgment.</li>
      </ul>
      
      <h3>Addressing Performance Anxiety</h3>
      
      <p>Performance anxiety is a common confidence barrier. Try these approaches:</p>
      
      <ul>
        <li><strong>Sensate Focus:</strong> A therapeutic technique that emphasizes sensation over performance.</li>
        <li><strong>Breathing Techniques:</strong> Deep, slow breathing to activate the parasympathetic nervous system.</li>
        <li><strong>Reframing:</strong> Seeing occasional challenges as normal rather than as failures.</li>
        <li><strong>Focusing Outward:</strong> Shifting attention to your partner and the shared experience.</li>
      </ul>
      
      <h3>Building Confidence Through Lifestyle</h3>
      
      <p>Your daily habits influence your intimate confidence:</p>
      
      <ul>
        <li><strong>Physical Wellness:</strong> Regular exercise, proper nutrition, and adequate sleep all support sexual function and confidence.</li>
        <li><strong>Stress Management:</strong> Developing effective stress-reduction techniques to prevent its interference with intimacy.</li>
        <li><strong>Mental Health:</strong> Addressing underlying anxiety or depression that may impact confidence.</li>
        <li><strong>Social Connection:</strong> Building a fulfilling life outside the bedroom contributes to confidence within it.</li>
      </ul>
      
      <h3>When To Seek Professional Support</h3>
      
      <p>Consider professional help if:</p>
      
      <ul>
        <li>Performance anxiety persists despite self-help strategies</li>
        <li>Past traumas affect your ability to be present during intimacy</li>
        <li>Relationship issues are creating barriers to confidence</li>
        <li>Physical issues are interfering with sexual function</li>
      </ul>
      
      <p>Remember that building confidence is a journey, not a destination. Be patient with yourself, celebrate progress, and approach intimate relationships with curiosity and care rather than pressure or expectations.</p>
    `,
    category: "Relationships",
    readTime: "6",
    imageUrl: "https://images.unsplash.com/photo-1516401266446-6432a8a07d41?w=800&auto=format&fit=crop",
    language: "en"
  },
  {
    id: "5",
    title: "Communication Strategies for Couples",
    description: "How to talk about sensitive topics with your partner and build stronger connections.",
    content: `
      <h2>Effective Communication Strategies for Intimate Topics</h2>
      
      <p>Open communication about intimate matters is essential for relationship satisfaction, yet many couples find these conversations challenging. This guide provides practical strategies for discussing sensitive topics with your partner.</p>
      
      <h3>Creating a Foundation for Intimate Communication</h3>
      
      <p>Before addressing specific intimate topics, establish these foundational elements:</p>
      
      <ul>
        <li><strong>Emotional Safety:</strong> Create an environment where both partners feel secure sharing vulnerable thoughts and feelings.</li>
        <li><strong>Regular Check-ins:</strong> Establish ongoing conversations about relationship satisfaction rather than waiting for problems.</li>
        <li><strong>Active Listening:</strong> Develop the habit of truly hearing your partner without planning your response.</li>
        <li><strong>Non-Judgment:</strong> Approach differences with curiosity rather than criticism.</li>
      </ul>
      
      <h3>Discussing Sexual Preferences and Desires</h3>
      
      <p>When communicating about intimate preferences:</p>
      
      <ul>
        <li><strong>Choose the Right Time:</strong> Have these conversations outside the bedroom when both partners are relaxed.</li>
        <li><strong>Use "I" Statements:</strong> Say "I enjoy..." or "I would like to try..." rather than "You never..." or "You should..."</li>
        <li><strong>Be Specific:</strong> Clear communication reduces misunderstandings and increases satisfaction.</li>
        <li><strong>Respect Boundaries:</strong> Acknowledge that each partner has the right to express preferences and limits.</li>
      </ul>
      
      <h3>Addressing Sexual Health Concerns</h3>
      
      <p>For conversations about health issues affecting intimacy:</p>
      
      <ul>
        <li><strong>Prepare What You'll Say:</strong> Consider writing down key points if the topic makes you anxious.</li>
        <li><strong>Focus on Solutions:</strong> Frame the conversation around working together to address the concern.</li>
        <li><strong>Avoid Blame:</strong> Present health issues as medical conditions, not personal shortcomings.</li>
        <li><strong>Consider Professional Support:</strong> Discuss seeing healthcare providers together when appropriate.</li>
      </ul>
      
      <h3>Navigating Differences in Desire</h3>
      
      <p>When partners have different levels of interest in intimacy:</p>
      
      <ul>
        <li><strong>Validate Both Experiences:</strong> Acknowledge that both higher and lower desire levels are normal variations.</li>
        <li><strong>Identify Influencing Factors:</strong> Discuss circumstances that affect desire, such as stress, health, or relationship dynamics.</li>
        <li><strong>Focus on Quality Connection:</strong> Explore ways to maintain intimacy that satisfy both partners' needs.</li>
        <li><strong>Develop Compromise Strategies:</strong> Create approaches that respect both partners' boundaries and desires.</li>
      </ul>
      
      <h3>Communication During Intimacy</h3>
      
      <p>Enhance connection through effective in-the-moment communication:</p>
      
      <ul>
        <li><strong>Establish Consent Practices:</strong> Develop comfortable ways to check in about boundaries and preferences.</li>
        <li><strong>Use Positive Guidance:</strong> Express what you enjoy rather than only what you don't.</li>
        <li><strong>Develop Non-Verbal Cues:</strong> Create signals that communicate needs without disrupting the moment.</li>
        <li><strong>Practice Presence:</strong> Focus on the current experience rather than past encounters or future concerns.</li>
      </ul>
      
      <h3>Recovering From Difficult Conversations</h3>
      
      <p>When discussions about intimacy don't go well:</p>
      
      <ul>
        <li><strong>Take a Break:</strong> It's okay to pause and return to the conversation when emotions are less intense.</li>
        <li><strong>Repair Attempts:</strong> Make small gestures to reconnect after tension.</li>
        <li><strong>Acknowledge Efforts:</strong> Recognize your partner's attempts to communicate, even if imperfect.</li>
        <li><strong>Learn and Adapt:</strong> Use challenging conversations as opportunities to improve communication skills.</li>
      </ul>
      
      <h3>When to Seek Professional Support</h3>
      
      <p>Consider relationship counseling or sex therapy if:</p>
      
      <ul>
        <li>Communication repeatedly breaks down despite your best efforts</li>
        <li>The same issues arise without resolution</li>
        <li>Significant differences in values or preferences create ongoing tension</li>
        <li>Past traumas interfere with present communication</li>
      </ul>
      
      <p>Remember that effective communication about intimate matters is a skill that develops with practice. Approach these conversations with patience, empathy, and a genuine desire to understand your partner's perspective.</p>
    `,
    category: "Relationships",
    readTime: "8",
    imageUrl: "https://images.unsplash.com/photo-1516575334481-f85287c2c82d?w=800&auto=format&fit=crop",
    language: "en"
  }
];

// Sample pre-loaded articles for Portuguese
const portugueseArticles: Article[] = [
  {
    id: "1-pt",
    title: "Entendendo os Fundamentos da Saúde Masculina",
    description: "Aprenda sobre os principais fatores que influenciam a saúde sexual masculina e como abordar preocupações comuns naturalmente.",
    content: `
      <h2>Os Fundamentos da Saúde Sexual Masculina</h2>
      
      <p>A saúde sexual masculina é influenciada por uma interação complexa de fatores físicos, psicológicos e sociais. Compreender esses componentes é crucial para manter o bem-estar geral e abordar preocupações de forma eficaz.</p>
      
      <h3>Fatores Físicos</h3>
      
      <p>Vários processos fisiológicos contribuem para uma função sexual saudável:</p>
      
      <ul>
        <li><strong>Equilíbrio Hormonal:</strong> A testosterona desempenha um papel crucial na libido, função erétil e níveis gerais de energia.</li>
        <li><strong>Saúde Cardiovascular:</strong> Um bom fluxo sanguíneo é essencial para a função sexual, tornando a saúde do coração uma prioridade.</li>
        <li><strong>Função Neurológica:</strong> O sistema nervoso coordena a excitação e as respostas físicas durante a atividade sexual.</li>
      </ul>
      
      <h3>Considerações Psicológicas</h3>
      
      <p>O bem-estar mental afeta significativamente a saúde sexual:</p>
      
      <ul>
        <li><strong>Gestão do Estresse:</strong> O estresse crônico pode esgotar a energia e reduzir o desejo sexual.</li>
        <li><strong>Ansiedade e Depressão:</strong> Essas condições frequentemente se correlacionam com disfunção sexual.</li>
        <li><strong>Imagem Corporal:</strong> Como os homens se percebem pode afetar a confiança e o desempenho.</li>
      </ul>
      
      <h3>Abordagens Naturais para Melhoria</h3>
      
      <p>Várias abordagens naturais baseadas em evidências podem apoiar a saúde sexual masculina:</p>
      
      <ul>
        <li><strong>Nutrição:</strong> Uma dieta rica em antioxidantes, gorduras saudáveis e nutrientes específicos pode melhorar a função sexual.</li>
        <li><strong>Exercício Regular:</strong> A atividade física melhora o fluxo sanguíneo, o equilíbrio hormonal e a confiança.</li>
        <li><strong>Sono de Qualidade:</strong> A otimização do sono impacta diretamente a produção de testosterona e os níveis de energia.</li>
        <li><strong>Redução do Estresse:</strong> Técnicas como mindfulness e meditação podem minimizar o impacto do estresse.</li>
      </ul>
      
      <h3>Quando Procurar Ajuda Profissional</h3>
      
      <p>Embora muitos aspectos da saúde sexual possam ser abordados por meio de mudanças no estilo de vida, certas situações requerem atenção médica:</p>
      
      <ul>
        <li>Dificuldades eréteis persistentes</li>
        <li>Mudanças significativas na libido</li>
        <li>Dor física durante a excitação ou relação sexual</li>
        <li>Preocupações sobre fertilidade</li>
      </ul>
      
      <p>Lembre-se de que preocupações com a saúde sexual são comuns e tratáveis. A comunicação aberta com profissionais de saúde é essencial para abordar problemas de forma eficaz.</p>
    `,
    category: "Educação",
    readTime: "5",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop",
    language: "pt"
  },
  {
    id: "2-pt",
    title: "Guia de Nutrição e Suplementos",
    description: "Descubra os nutrientes essenciais e suplementos que podem melhorar sua saúde sexual e bem-estar geral.",
    content: `
      <h2>Otimizando a Nutrição para a Saúde Sexual</h2>
      
      <p>O que você come tem um impacto direto em sua saúde sexual e desempenho. Este guia explora os principais nutrientes e suplementos que podem fazer uma diferença significativa.</p>
      
      <h3>Nutrientes Chave para a Função Sexual Masculina</h3>
      
      <ul>
        <li><strong>Zinco:</strong> Essencial para a produção de testosterona e saúde dos espermatozoides. Encontrado em ostras, sementes de abóbora e carne bovina.</li>
        <li><strong>L-arginina:</strong> Um aminoácido que melhora o fluxo sanguíneo aumentando a produção de óxido nítrico. Encontrado em peru, frango e sementes de abóbora.</li>
        <li><strong>Vitamina D:</strong> Ligada à produção de testosterona e vitalidade geral. Fonte primária é a luz solar, mas também encontrada em peixes gordurosos e alimentos fortificados.</li>
        <li><strong>Ácidos Graxos Ômega-3:</strong> Suportam a saúde cardiovascular e o fluxo sanguíneo. Encontrados em peixes gordurosos, sementes de linhaça e nozes.</li>
      </ul>
      
      <h3>Padrões Alimentares para Desempenho Ideal</h3>
      
      <p>Pesquisas sugerem que as seguintes abordagens dietéticas podem beneficiar a saúde sexual:</p>
      
      <ul>
        <li><strong>Dieta Mediterrânea:</strong> Rica em vegetais, frutas, grãos integrais, proteínas magras e gorduras saudáveis. Associada a taxas mais baixas de disfunção erétil.</li>
        <li><strong>Alimentos Anti-inflamatórios:</strong> Bagas, folhas verdes, peixes gordurosos e nozes podem reduzir a inflamação que contribui para a disfunção sexual.</li>
        <li><strong>Hidratação:</strong> A ingestão adequada de líquidos suporta a circulação e a função física geral.</li>
      </ul>
      
      <h3>Suplementos com Suporte Científico</h3>
      
      <p>Embora alimentos integrais devam ser sua fonte primária de nutrição, certos suplementos mostraram-se promissores para apoiar a saúde sexual masculina:</p>
      
      <ul>
        <li><strong>Raiz de Maca:</strong> Tradicionalmente usada para aumentar a libido e a resistência.</li>
        <li><strong>Ginseng Panax:</strong> Pode melhorar a função erétil e a satisfação sexual.</li>
        <li><strong>Ashwagandha:</strong> Pode ajudar a reduzir o estresse e potencialmente aumentar os níveis de testosterona.</li>
        <li><strong>Feno-grego:</strong> Alguns estudos sugerem que pode apoiar níveis saudáveis de testosterona.</li>
      </ul>
      
      <h3>Alimentos a Limitar ou Evitar</h3>
      
      <p>Certas escolhas dietéticas podem impactar negativamente a saúde sexual:</p>
      
      <ul>
        <li><strong>Álcool Excessivo:</strong> Pode reduzir a testosterona e prejudicar a função sexual.</li>
        <li><strong>Alimentos Processados:</strong> Ricos em compostos inflamatórios que podem afetar a circulação.</li>
        <li><strong>Açúcares Adicionados:</strong> Podem contribuir para condições que prejudicam a saúde sexual, como diabetes e obesidade.</li>
        <li><strong>Gorduras Trans:</strong> Podem danificar os vasos sanguíneos e prejudicar a circulação.</li>
      </ul>
      
      <h3>Criando um Plano de Nutrição Sustentável</h3>
      
      <p>A melhor estratégia nutricional é aquela que você pode manter a longo prazo:</p>
      
      <ul>
        <li>Foque em alimentos integrais, minimamente processados.</li>
        <li>Garanta uma ingestão adequada de proteínas para a produção de hormônios.</li>
        <li>Inclua uma variedade de frutas e vegetais coloridos.</li>
        <li>Mantenha-se hidratado ao longo do dia.</li>
        <li>Considere trabalhar com um nutricionista para orientação personalizada.</li>
      </ul>
      
      <p>Lembre-se de que a nutrição é apenas uma peça do quebra-cabeça. Combine essas estratégias dietéticas com exercícios regulares, gestão do estresse e sono de qualidade para resultados ideais.</p>
    `,
    category: "Nutrição",
    readTime: "7",
    imageUrl: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=800&auto=format&fit=crop",
    language: "pt"
  },
  {
    id: "3-pt",
    title: "Otimização do Sono e Recuperação",
    description: "Como o sono de qualidade impacta diretamente sua produção hormonal e saúde sexual.",
    content: `
      <h2>A Conexão Crítica Entre Sono e Saúde Sexual</h2>
      
      <p>O sono de qualidade é um pilar fundamental da saúde sexual que é frequentemente negligenciado. Este artigo explora como o sono afeta a produção hormonal, os níveis de energia e a função sexual geral.</p>
      
      <h3>Sono e Regulação Hormonal</h3>
      
      <p>O sono desempenha um papel crucial no equilíbrio hormonal:</p>
      
      <ul>
        <li><strong>Produção de Testosterona:</strong> A maioria da liberação diária de testosterona ocorre durante o sono REM. Sono insuficiente pode reduzir os níveis de testosterona em 10-15%.</li>
        <li><strong>Gerenciamento de Cortisol:</strong> Sono ruim aumenta o cortisol (hormônio do estresse), que pode inibir a função sexual e reduzir a libido.</li>
        <li><strong>Hormônio do Crescimento:</strong> Este importante hormônio de recuperação é principalmente liberado durante as fases de sono profundo.</li>
      </ul>
      
      <h3>Como a Privação de Sono Afeta a Saúde Sexual</h3>
      
      <p>Pesquisas identificaram várias maneiras pelas quais o sono inadequado impacta o bem-estar sexual:</p>
      
      <ul>
        <li><strong>Desejo Reduzido:</strong> Indivíduos privados de sono relatam níveis mais baixos de interesse sexual e excitação.</li>
        <li><strong>Função Erétil:</strong> Estudos mostram uma correlação entre distúrbios do sono como apneia do sono e dificuldades eréteis.</li>
        <li><strong>Energia e Resistência:</strong> Sono ruim diminui as reservas de energia física necessárias para atividade sexual satisfatória.</li>
        <li><strong>Regulação do Humor:</strong> A privação de sono aumenta a irritabilidade e diminui os estados de humor positivos que apoiam a intimidade.</li>
      </ul>
      
      <h3>Otimizando Seu Sono para Saúde Sexual</h3>
      
      <p>Implemente estas estratégias baseadas em evidências para melhorar a qualidade do seu sono:</p>
      
      <ul>
        <li><strong>Programação Consistente:</strong> Vá para a cama e acorde nos mesmos horários todos os dias, mesmo nos fins de semana.</li>
        <li><strong>Ambiente de Sono:</strong> Mantenha seu quarto fresco (18-20°C), escuro e silencioso.</li>
        <li><strong>Pôr-do-sol Digital:</strong> Evite telas 1-2 horas antes de dormir para apoiar a produção natural de melatonina.</li>
        <li><strong>Rotina de Relaxamento:</strong> Desenvolva um ritual pré-sono que sinalize ao seu corpo que é hora de desacelerar.</li>
        <li><strong>Tempo de Nutrição:</strong> Evite refeições grandes, cafeína e álcool perto da hora de dormir.</li>
      </ul>
      
      <h3>Suplementos Naturais de Apoio ao Sono</h3>
      
      <p>Considere estas opções apoiadas por evidências se você tem dificuldades com o sono:</p>
      
      <ul>
        <li><strong>Magnésio:</strong> Promove relaxamento e qualidade do sono. Encontrado em chocolate amargo, nozes e folhas verdes.</li>
        <li><strong>Melatonina:</strong> Pode ajudar a redefinir os ciclos de sono quando usada apropriadamente.</li>
        <li><strong>L-teanina:</strong> Um aminoácido encontrado no chá que promove relaxamento sem sonolência.</li>
        <li><strong>Raiz de Valeriana:</strong> Erva tradicional usada para melhorar a qualidade do sono.</li>
      </ul>
      
      <h3>Quando Procurar Ajuda Profissional</h3>
      
      <p>Considere consultar um profissional de saúde se você experimentar:</p>
      
      <ul>
        <li>Insônia persistente apesar de boas práticas de higiene do sono</li>
        <li>Ronco acompanhado de suspiros ou engasgos (possível apneia do sono)</li>
        <li>Sonolência diurna excessiva</li>
        <li>Pernas inquietas ou movimentos periódicos dos membros que perturbam o sono</li>
      </ul>
      
      <p>Lembre-se que investir na qualidade do seu sono é investir na sua saúde sexual e bem-estar geral. Faça do sono uma prioridade, e você provavelmente verá melhorias em múltiplos aspectos da sua vida.</p>
    `,
    category: "Estilo de vida",
    readTime: "6",
    imageUrl: "https://images.unsplash.com/photo-1519003300449-424ad0405076?w=800&auto=format&fit=crop",
    language: "pt"
  }
];

// Forum Threads
const forumThreads: ForumThread[] = [
  {
    id: "thread1",
    title: "How long before I see results?",
    content: "I've been taking the supplements for about a week now. How long should I expect to wait before noticing any improvements? I understand these things take time, but I'm curious about others' experiences.",
    authorName: "HealthSeeker28",
    replies: 12,
    lastActivity: "2 hours ago",
    language: "en"
  },
  {
    id: "thread2",
    title: "Best time of day to take supplements?",
    content: "I'm wondering if there's an optimal time to take these supplements for best results. Morning? Evening? With meals or on an empty stomach? Any advice would be appreciated!",
    authorName: "WellnessJourney",
    replies: 8,
    lastActivity: "1 day ago",
    language: "en"
  },
  {
    id: "thread3",
    title: "Combining with other supplements?",
    content: "Is it safe to combine these capsules with other supplements like multivitamins, protein powders, or pre-workouts? I already have a supplement routine and want to make sure there are no negative interactions.",
    authorName: "FitnessFirst42",
    replies: 15,
    lastActivity: "3 days ago",
    language: "en"
  },
  {
    id: "thread1-pt",
    title: "Quanto tempo até ver resultados?",
    content: "Estou tomando os suplementos há cerca de uma semana. Quanto tempo devo esperar até notar alguma melhora? Entendo que essas coisas levam tempo, mas estou curioso sobre as experiências de outros.",
    authorName: "BuscaSaúde28",
    replies: 12,
    lastActivity: "2 horas atrás",
    language: "pt"
  },
  {
    id: "thread2-pt",
    title: "Melhor hora do dia para tomar suplementos?",
    content: "Estou me perguntando se há um momento ideal para tomar esses suplementos para obter melhores resultados. Manhã? Noite? Com refeições ou com o estômago vazio? Qualquer conselho seria apreciado!",
    authorName: "JornadaBemEstar",
    replies: 8,
    lastActivity: "1 dia atrás",
    language: "pt"
  },
  {
    id: "thread3-pt",
    title: "Combinando com outros suplementos?",
    content: "É seguro combinar essas cápsulas com outros suplementos como multivitamínicos, pós de proteína ou pré-treinos? Já tenho uma rotina de suplementos e quero ter certeza de que não há interações negativas.",
    authorName: "PrimeiroFitness42",
    replies: 15,
    lastActivity: "3 dias atrás",
    language: "pt"
  }
];

// Forum Replies
const forumReplies: {[key: string]: ForumReply[]} = {
  "thread1": [
    {
      id: "reply1-1",
      threadId: "thread1",
      content: "In my experience, it took about 3 weeks before I started noticing subtle changes. By week 6, the effects were much more noticeable. Stick with it and make sure you're consistent with taking them as directed.",
      authorName: "HealthCoach",
      isExpert: true,
      expertTitle: "Nutritionist",
      postedAt: "1 day ago",
      language: "en"
    },
    {
      id: "reply1-2",
      threadId: "thread1",
      content: "I noticed small improvements after about 10 days, particularly in my energy levels. The full benefits took closer to a month. Remember that everyone's body responds differently!",
      authorName: "FitnessJunkie",
      isExpert: false,
      postedAt: "16 hours ago",
      language: "en"
    }
  ],
  "thread2": [
    {
      id: "reply2-1",
      threadId: "thread2",
      content: "For these particular supplements, taking them with a meal that contains some healthy fats can improve absorption. I typically recommend dividing the daily dose - half in the morning with breakfast and half in the evening with dinner. This approach helps maintain more consistent levels in your system throughout the day.",
      authorName: "Dr. Wellness",
      isExpert: true,
      expertTitle: "Sexologist",
      postedAt: "20 hours ago",
      language: "en"
    }
  ],
  "thread3": [
    {
      id: "reply3-1",
      threadId: "thread3",
      content: "While these supplements are generally safe to combine with basic vitamins and minerals, I would recommend spacing them at least 2 hours apart from any pre-workout supplements that contain stimulants. Also, always check with your healthcare provider if you're taking any prescription medications, as some botanical ingredients might have interactions.",
      authorName: "NutritionExpert",
      isExpert: true,
      expertTitle: "Clinical Nutritionist",
      postedAt: "2 days ago",
      language: "en"
    }
  ]
};

const Content: React.FC = () => {
  const { t, language } = useLanguage();
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [selectedThread, setSelectedThread] = useState<ForumThread | null>(null);
  
  // Filter articles based on current language
  const filteredArticles = language === 'en' ? englishArticles : portugueseArticles;
  
  // Filter forum threads based on current language
  const filteredThreads = forumThreads.filter(thread => thread.language === language);
  
  const handleArticleClick = (article: Article) => {
    setSelectedArticle(article);
  };
  
  const handleThreadClick = (thread: ForumThread) => {
    setSelectedThread(thread);
  };
  
  const closeArticle = () => {
    setSelectedArticle(null);
  };
  
  const closeThread = () => {
    setSelectedThread(null);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-3">{t('content')}</h1>
        <p className="text-muted-foreground">
          Access exclusive educational content and resources for your journey.
        </p>
      </div>
      
      <Tabs defaultValue="education" className="w-full">
        <TabsList className="w-full flex justify-start mb-6 overflow-x-auto">
          <TabsTrigger value="education">{t('articles')}</TabsTrigger>
          <TabsTrigger value="relationships">{t('relationshipTips')}</TabsTrigger>
          <TabsTrigger value="forum">{t('forum')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="education" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles
              .filter(article => article.category === "Education" || article.category === "Nutrition" || article.category === "Lifestyle" || 
                article.category === "Educação" || article.category === "Nutrição" || article.category === "Estilo de vida")
              .map(article => (
                <ArticlePreview 
                  key={article.id}
                  title={article.title}
                  description={article.description}
                  category={article.category}
                  readTime={article.readTime}
                  imageUrl={article.imageUrl}
                  onClick={() => handleArticleClick(article)}
                />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="relationships" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles
              .filter(article => article.category === "Relationships" || article.category === "Relacionamentos")
              .map(article => (
                <ArticlePreview 
                  key={article.id}
                  title={article.title}
                  description={article.description}
                  category={article.category}
                  readTime={article.readTime}
                  imageUrl={article.imageUrl}
                  onClick={() => handleArticleClick(article)}
                />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="forum" className="space-y-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-xl font-medium mb-4">{t('forum')} & {t('askExpert')}</h3>
            <p className="text-muted-foreground mb-6">
              Connect with other users and get answers from certified professionals.
            </p>
            
            <div className="space-y-4 border-t pt-4">
              {filteredThreads.map(thread => (
                <div 
                  key={thread.id}
                  className="flex items-center justify-between p-4 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => handleThreadClick(thread)}
                >
                  <div>
                    <h4 className="font-medium">{thread.title}</h4>
                    <p className="text-sm text-muted-foreground">Last activity: {thread.lastActivity}</p>
                  </div>
                  <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                    {thread.replies} replies
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Article Dialog */}
      <Dialog open={selectedArticle !== null} onOpenChange={closeArticle}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedArticle && (
            <>
              <DialogHeader>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="absolute left-2 top-2 p-2" 
                  onClick={closeArticle}
                >
                  <ArrowLeft size={18} />
                </Button>
                
                <div className="mt-6">
                  <Badge className="mb-2">{selectedArticle.category}</Badge>
                  <DialogTitle className="text-2xl">{selectedArticle.title}</DialogTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                    <Clock size={14} />
                    <span>{selectedArticle.readTime} min read</span>
                  </div>
                </div>
              </DialogHeader>
              
              {selectedArticle.imageUrl && (
                <div className="w-full h-56 md:h-72 overflow-hidden rounded-md my-4">
                  <img 
                    src={selectedArticle.imageUrl} 
                    alt={selectedArticle.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              <div 
                className="prose prose-lg max-w-none" 
                dangerouslySetInnerHTML={{ __html: selectedArticle.content }}
              />
              
              <div className="flex justify-between items-center mt-8 pt-4 border-t">
                <div className="flex items-center gap-3">
                  <Button variant="outline" size="sm">
                    <Bookmark size={16} className="mr-1" /> Save
                  </Button>
                  <Button variant="outline" size="sm">
                    <Heart size={16} className="mr-1" /> Like
                  </Button>
                </div>
                <Button variant="ghost" size="sm" onClick={closeArticle}>Close</Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Forum Thread Dialog */}
      <Dialog open={selectedThread !== null} onOpenChange={closeThread}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedThread && (
            <>
              <DialogHeader>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="absolute left-2 top-2 p-2" 
                  onClick={closeThread}
                >
                  <ArrowLeft size={18} />
                </Button>
                
                <div className="mt-6">
                  <DialogTitle className="text-2xl">{selectedThread.title}</DialogTitle>
                  <DialogDescription className="text-base mt-2">
                    {selectedThread.content}
                  </DialogDescription>
                  
                  <div className="flex items-center gap-2 mt-4">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback>{selectedThread.authorName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{selectedThread.authorName}</span>
                    <span className="text-xs text-muted-foreground">{selectedThread.lastActivity}</span>
                  </div>
                </div>
              </DialogHeader>
              
              <Separator className="my-4" />
              
              <div className="space-y-6">
                <h3 className="font-medium flex items-center gap-2">
                  <MessageCircle size={18} />
                  <span>Replies ({selectedThread.replies})</span>
                </h3>
                
                {forumReplies[selectedThread.id]?.map((reply) => (
                  <Card key={reply.id} className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarFallback>{reply.authorName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{reply.authorName}</span>
                          {reply.isExpert && (
                            <Badge variant="secondary" className="flex items-center gap-1">
                              <Award size={12} />
                              <span>{reply.expertTitle}</span>
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">{reply.postedAt}</span>
                        </div>
                        
                        <p className="mt-2">{reply.content}</p>
                        
                        <div className="flex items-center gap-4 mt-4">
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <Heart size={14} className="mr-1" /> Like
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <MessageSquare size={14} className="mr-1" /> Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
                
                {!forumReplies[selectedThread.id] && (
                  <p className="text-center text-muted-foreground py-4">
                    No replies yet. Be the first to respond!
                  </p>
                )}
                
                <div className="mt-4 pt-4 border-t">
                  <h4 className="font-medium mb-2">Add your reply</h4>
                  <textarea 
                    className="w-full p-3 border rounded-md min-h-24 focus:outline-none focus:ring-2 focus:ring-primary/50"
                    placeholder="Share your thoughts or ask a follow-up question..."
                  />
                  <div className="flex justify-end mt-2">
                    <Button>
                      <MessageCircle size={16} className="mr-2" /> Post Reply
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Content;
