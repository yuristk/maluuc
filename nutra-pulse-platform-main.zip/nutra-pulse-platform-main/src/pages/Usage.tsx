
import React from 'react';
import UsageCalendar from '@/components/UsageModule/UsageCalendar';
import { useLanguage } from '@/context/LanguageContext';

const Usage: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-3">{t('usage')}</h1>
        <p className="text-muted-foreground">
          Track your daily usage and optimize your protocol for maximum results.
        </p>
      </div>
      
      <div className="space-y-8">
        <UsageCalendar />
        
        {/* Future components will go here */}
        {/* - Protocol Settings */}
        {/* - Usage Statistics */}
        {/* - Daily Feedback System */}
      </div>
    </div>
  );
};

export default Usage;
