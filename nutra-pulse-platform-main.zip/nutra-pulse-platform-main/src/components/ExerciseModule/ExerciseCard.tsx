
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Play, Timer, CheckCircle } from 'lucide-react';

interface ExerciseCardProps {
  title: string;
  description: string;
  duration: string;
  imageUrl?: string;
  completed?: boolean;
  onClick?: () => void;
}

const ExerciseCard: React.FC<ExerciseCardProps> = ({
  title,
  description,
  duration,
  imageUrl,
  completed = false,
  onClick
}) => {
  return (
    <Card className="glass-card overflow-hidden transition-all duration-300 hover:shadow-md hover:translate-y-[-2px]">
      {imageUrl && (
        <div className="w-full h-40 overflow-hidden">
          <img 
            src={imageUrl} 
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          />
        </div>
      )}
      
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{title}</CardTitle>
            <CardDescription>{description}</CardDescription>
          </div>
          {completed && (
            <div className="rounded-full bg-green-100 p-1">
              <CheckCircle className="h-5 w-5 text-green-600" />
            </div>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="pb-2">
        <div className="flex items-center text-sm text-muted-foreground">
          <Timer className="mr-1 h-4 w-4" />
          <span>{duration}</span>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button className="w-full" onClick={onClick}>
          <Play className="mr-2 h-4 w-4" />
          Start Exercise
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ExerciseCard;
