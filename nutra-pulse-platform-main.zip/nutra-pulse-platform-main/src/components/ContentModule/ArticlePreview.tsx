
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Clock } from 'lucide-react';

interface ArticlePreviewProps {
  title: string;
  description: string;
  category: string;
  readTime: string;
  imageUrl?: string;
  onClick?: () => void;
}

const ArticlePreview: React.FC<ArticlePreviewProps> = ({
  title,
  description,
  category,
  readTime,
  imageUrl,
  onClick
}) => {
  return (
    <Card className="glass-card overflow-hidden transition-all duration-300 hover:shadow-md hover:translate-y-[-2px]">
      {imageUrl && (
        <div className="w-full h-48 overflow-hidden">
          <img 
            src={imageUrl} 
            alt={title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          />
        </div>
      )}
      
      <CardHeader className="pb-2">
        <div className="flex flex-col gap-2">
          <Badge className="self-start" variant="secondary">{category}</Badge>
          <CardTitle className="text-xl">{title}</CardTitle>
        </div>
      </CardHeader>
      
      <CardContent className="pb-2">
        <CardDescription className="line-clamp-3">
          {description}
        </CardDescription>
        
        <div className="flex items-center mt-4 text-sm text-muted-foreground">
          <Clock className="mr-1 h-4 w-4" />
          <span>{readTime} min read</span>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button variant="ghost" className="px-0 hover:bg-transparent hover:text-primary" onClick={onClick}>
          Read Article
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ArticlePreview;
