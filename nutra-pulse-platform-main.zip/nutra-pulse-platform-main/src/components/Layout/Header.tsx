
import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { 
  MenuIcon, 
  XIcon, 
  User, 
  Settings, 
  Home, 
  Calendar, 
  Dumbbell, 
  BookOpen, 
  LineChart,
  LogOut
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/context/LanguageContext';
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();
  const isMobile = useIsMobile();
  const { toast } = useToast();

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'pt' : 'en';
    setLanguage(newLang);
    toast({
      title: newLang === 'en' ? 'Language Changed' : 'Idioma Alterado',
      description: newLang === 'en' ? 'English is now active' : 'Português está agora ativo',
    });
  };

  const handleProfileClick = () => {
    toast({
      title: "Profile",
      description: "Profile features coming soon",
    });
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center">
          <Link 
            to="/" 
            className="text-xl font-semibold text-primary flex items-center gap-2 transition-transform hover:scale-[1.02] duration-300"
          >
            <span className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
              N
            </span>
            <span>{t('appName')}</span>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center space-x-1">
          <NavLinks t={t} className="flex" />
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-sm font-medium" 
            onClick={toggleLanguage}
          >
            {language === 'en' ? 'PT' : 'EN'}
          </Button>
          
          {!isMobile && (
            <>
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-2"
                onClick={handleProfileClick}
              >
                <User className="w-5 h-5" />
              </Button>
              
              <Button 
                variant="ghost" 
                size="sm" 
                className="p-2"
                onClick={() => toast({
                  title: "Settings",
                  description: "Settings panel coming soon",
                })}
              >
                <Settings className="w-5 h-5" />
              </Button>
            </>
          )}
          
          <div className="block md:hidden">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2"
            >
              {isMenuOpen ? (
                <XIcon className="w-5 h-5" />
              ) : (
                <MenuIcon className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-md border-b border-border animate-fade-in">
          <div className="container mx-auto px-4 py-4">
            <NavLinks t={t} className="flex flex-col space-y-3" />
            
            <div className="mt-6 pt-4 border-t flex flex-col space-y-2">
              <MobileNavLink 
                to="/profile" 
                icon={<User className="w-4 h-4" />} 
                label="Profile" 
                onClick={handleProfileClick}
              />
              <MobileNavLink 
                to="/settings" 
                icon={<Settings className="w-4 h-4" />} 
                label="Settings" 
                onClick={() => toast({
                  title: "Settings",
                  description: "Settings panel coming soon",
                })}
              />
              <MobileNavLink 
                to="/logout" 
                icon={<LogOut className="w-4 h-4" />} 
                label="Logout" 
                onClick={() => toast({
                  title: "Logout",
                  description: "Logout functionality coming soon",
                })}
              />
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

interface NavLinksProps {
  t: (key: any) => string;
  className?: string;
}

const NavLinks: React.FC<NavLinksProps> = ({ t, className = "" }) => {
  return (
    <nav className={className}>
      <NavLink 
        to="/" 
        className={({ isActive }) => 
          `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2
          ${isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'}`
        }
      >
        <Home className="w-4 h-4" />
        <span>{t('home')}</span>
      </NavLink>
      
      <NavLink 
        to="/usage" 
        className={({ isActive }) => 
          `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2
          ${isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'}`
        }
      >
        <Calendar className="w-4 h-4" />
        <span>{t('usage')}</span>
      </NavLink>
      
      <NavLink 
        to="/exercises" 
        className={({ isActive }) => 
          `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2
          ${isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'}`
        }
      >
        <Dumbbell className="w-4 h-4" />
        <span>{t('exercises')}</span>
      </NavLink>
      
      <NavLink 
        to="/content" 
        className={({ isActive }) => 
          `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2
          ${isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'}`
        }
      >
        <BookOpen className="w-4 h-4" />
        <span>{t('content')}</span>
      </NavLink>
      
      <NavLink 
        to="/progress" 
        className={({ isActive }) => 
          `px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2
          ${isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'}`
        }
      >
        <LineChart className="w-4 h-4" />
        <span>{t('progress')}</span>
      </NavLink>
    </nav>
  );
};

interface MobileNavLinkProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
}

const MobileNavLink: React.FC<MobileNavLinkProps> = ({ to, icon, label, onClick }) => {
  return (
    <Button
      variant="ghost"
      className="w-full justify-start px-3 py-2"
      onClick={onClick}
    >
      {icon}
      <span className="ml-2">{label}</span>
    </Button>
  );
};

export default Header;
