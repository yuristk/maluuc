
import React, { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { NotificationChannel, ScheduleFormData } from './UsageTypes';
import { useLanguage } from '@/context/LanguageContext';
import { Check, Plus, X } from 'lucide-react';

interface ScheduleIntakeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSchedule: (data: ScheduleFormData) => void;
  initialDate?: Date;
}

const ScheduleIntakeDialog: React.FC<ScheduleIntakeDialogProps> = ({
  isOpen,
  onClose,
  onSchedule,
  initialDate = new Date(),
}) => {
  const { t } = useLanguage();
  const [selectedDate, setSelectedDate] = useState<Date>(initialDate);
  const [timeSlots, setTimeSlots] = useState<string[]>(['09:00']);
  const [notificationChannels, setNotificationChannels] = useState<NotificationChannel[]>(['push']);

  const addTimeSlot = () => {
    if (timeSlots.length < 2) {
      setTimeSlots([...timeSlots, '']);
    }
  };

  const removeTimeSlot = (index: number) => {
    setTimeSlots(timeSlots.filter((_, i) => i !== index));
  };

  const updateTimeSlot = (index: number, value: string) => {
    const newTimeSlots = [...timeSlots];
    newTimeSlots[index] = value;
    setTimeSlots(newTimeSlots);
  };

  const toggleNotificationChannel = (channel: NotificationChannel) => {
    if (notificationChannels.includes(channel)) {
      setNotificationChannels(notificationChannels.filter(c => c !== channel));
    } else {
      setNotificationChannels([...notificationChannels, channel]);
    }
  };

  const handleSubmit = () => {
    // Validate all time slots are filled
    if (timeSlots.some(slot => !slot)) {
      return;
    }

    onSchedule({
      date: selectedDate,
      timeSlots,
      notificationChannels,
    });

    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{t('scheduleIntake')}</DialogTitle>
          <DialogDescription>
            {t('scheduleIntakeDescription')}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>{t('selectDate')}</Label>
            <div className="border rounded-md p-1">
              <Calendar 
                mode="single" 
                selected={selectedDate}
                onSelect={(date) => date && setSelectedDate(date)}
                className="rounded-md pointer-events-auto"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <Label>{t('timeSlots')}</Label>
              {timeSlots.length < 2 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addTimeSlot}
                  className="h-8 gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>{t('addTimeSlot')}</span>
                </Button>
              )}
            </div>
            
            <div className="space-y-2">
              {timeSlots.map((time, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Input
                    type="time"
                    value={time}
                    onChange={(e) => updateTimeSlot(index, e.target.value)}
                    className="flex-1"
                  />
                  {timeSlots.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeTimeSlot(index)}
                      className="h-8 w-8"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('notificationChannels')}</Label>
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant={notificationChannels.includes('push') ? 'default' : 'outline'}
                size="sm"
                onClick={() => toggleNotificationChannel('push')}
                className="gap-1"
              >
                {notificationChannels.includes('push') && <Check className="h-3.5 w-3.5" />}
                <span>{t('pushNotification')}</span>
              </Button>
              <Button
                type="button"
                variant={notificationChannels.includes('email') ? 'default' : 'outline'}
                size="sm"
                onClick={() => toggleNotificationChannel('email')}
                className="gap-1"
              >
                {notificationChannels.includes('email') && <Check className="h-3.5 w-3.5" />}
                <span>{t('email')}</span>
              </Button>
              <Button
                type="button"
                variant={notificationChannels.includes('whatsapp') ? 'default' : 'outline'}
                size="sm"
                onClick={() => toggleNotificationChannel('whatsapp')}
                className="gap-1"
              >
                {notificationChannels.includes('whatsapp') && <Check className="h-3.5 w-3.5" />}
                <span>{t('whatsapp')}</span>
              </Button>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button onClick={handleSubmit}>
            {t('schedule')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ScheduleIntakeDialog;
