
export interface UsageEvent {
  date: Date;
  taken: boolean;
  capsule1Taken: boolean;
  capsule2Taken: boolean;
}

export interface ScheduledIntake {
  id: string;
  date: Date;
  timeSlots: string[];
  notificationChannels: NotificationChannel[];
}

export type NotificationChannel = "push" | "email" | "whatsapp";

export interface ScheduleFormData {
  date: Date;
  timeSlots: string[];
  notificationChannels: NotificationChannel[];
}

export interface FeedbackData {
  date: Date;
  improvement: number; // 1-5 scale
  sideEffects: string;
  wellbeing: number; // 1-5 scale
}

export interface Article {
  id: string;
  title: string;
  description: string;
  content: string;
  category: string;
  readTime: string;
  imageUrl: string;
  language: string;
}

export interface ForumThread {
  id: string;
  title: string;
  content: string;
  authorName: string;
  replies: number;
  lastActivity: string;
  language: string;
}

export interface ForumReply {
  id: string;
  threadId: string;
  content: string;
  authorName: string;
  isExpert: boolean;
  expertTitle?: string;
  postedAt: string;
  language: string;
}
