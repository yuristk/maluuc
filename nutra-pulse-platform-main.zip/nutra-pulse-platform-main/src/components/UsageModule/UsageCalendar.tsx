
import React, { useState, useEffect } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, Check, Clock, Info, Plus, Calendar as CalendarIcon } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { useToast } from "@/hooks/use-toast";
import { v4 as uuidv4 } from 'uuid';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { UsageEvent, ScheduledIntake, ScheduleFormData } from './UsageTypes';
import ScheduleIntakeDialog from './ScheduleIntakeDialog';
import { Checkbox } from '@/components/ui/checkbox';

const UsageCalendar: React.FC = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [date, setDate] = useState<Date>(new Date());
  const [events, setEvents] = useState<UsageEvent[]>([]);
  const [scheduledIntakes, setScheduledIntakes] = useState<ScheduledIntake[]>([]);
  const [reminderTime, setReminderTime] = useState<string>('09:00');
  const [selectedProtocol, setSelectedProtocol] = useState<string>('30-7');
  const [isScheduleDialogOpen, setIsScheduleDialogOpen] = useState(false);
  
  // Calculate protocol day
  const startDate = new Date(2025, 0, 1); // Example protocol start date
  const protocolDay = Math.floor((new Date().getTime() - startDate.getTime()) / (1000 * 3600 * 24)) + 1;
  const isOffCycle = selectedProtocol === '30-7' && protocolDay > 30 && protocolDay <= 37;

  // Convert stored dates back to Date objects
  const parseDates = <T extends { date: Date }>(items: string | null, itemType: string): T[] => {
    if (!items) return [];
    try {
      return JSON.parse(items).map((item: any) => ({
        ...item,
        date: new Date(item.date)
      }));
    } catch (error) {
      console.error(`Error parsing ${itemType}:`, error);
      return [];
    }
  };

  // Load saved data from localStorage on component mount
  useEffect(() => {
    const savedEvents = localStorage.getItem('usageEvents');
    const savedSchedules = localStorage.getItem('scheduledIntakes');
    
    setEvents(parseDates<UsageEvent>(savedEvents, 'events'));
    setScheduledIntakes(parseDates<ScheduledIntake>(savedSchedules, 'schedules'));
    
    // Load reminder time
    const savedReminderTime = localStorage.getItem('reminderTime');
    if (savedReminderTime) {
      setReminderTime(savedReminderTime);
    }
    
    // Load protocol setting
    const savedProtocol = localStorage.getItem('selectedProtocol');
    if (savedProtocol) {
      setSelectedProtocol(savedProtocol);
    }
  }, []);

  // Save data to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('usageEvents', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('scheduledIntakes', JSON.stringify(scheduledIntakes));
  }, [scheduledIntakes]);

  useEffect(() => {
    localStorage.setItem('reminderTime', reminderTime);
  }, [reminderTime]);

  useEffect(() => {
    localStorage.setItem('selectedProtocol', selectedProtocol);
  }, [selectedProtocol]);

  const handleDateSelect = (selectedDate: Date | undefined) => {
    if (selectedDate) {
      setDate(selectedDate);
    }
  };

  const getEventForDate = (dateToCheck: Date) => {
    return events.find(
      event => event.date.toDateString() === dateToCheck.toDateString()
    );
  };

  const toggleCapsuleStatus = (capsuleNumber: 1 | 2) => {
    const existingEventIndex = events.findIndex(
      event => event.date.toDateString() === date.toDateString()
    );

    if (existingEventIndex >= 0) {
      // Update existing event
      const updatedEvents = [...events];
      const eventToUpdate = { ...updatedEvents[existingEventIndex] };
      
      if (capsuleNumber === 1) {
        eventToUpdate.capsule1Taken = !eventToUpdate.capsule1Taken;
      } else {
        eventToUpdate.capsule2Taken = !eventToUpdate.capsule2Taken;
      }
      
      // Calculate if both capsules are taken
      eventToUpdate.taken = eventToUpdate.capsule1Taken && eventToUpdate.capsule2Taken;
      
      updatedEvents[existingEventIndex] = eventToUpdate;
      setEvents(updatedEvents);
      
      toast({
        title: capsuleNumber === 1 
          ? (eventToUpdate.capsule1Taken ? "Capsule 1 marked as taken" : "Capsule 1 marked as not taken") 
          : (eventToUpdate.capsule2Taken ? "Capsule 2 marked as taken" : "Capsule 2 marked as not taken"),
        description: t('usageUpdateDescription', { date: date.toLocaleDateString() }),
      });
    } else {
      // Create new event
      const newEvent: UsageEvent = {
        date: new Date(date),
        taken: false,
        capsule1Taken: capsuleNumber === 1,
        capsule2Taken: capsuleNumber === 2
      };
      
      // If both capsules are taken, mark the day as completed
      newEvent.taken = newEvent.capsule1Taken && newEvent.capsule2Taken;
      
      setEvents([...events, newEvent]);
      
      toast({
        title: capsuleNumber === 1 ? "Capsule 1 marked as taken" : "Capsule 2 marked as taken",
        description: t('usageRecorded', { date: date.toLocaleDateString() }),
      });
    }
  };

  const isCapsuleTaken = (capsuleNumber: 1 | 2) => {
    const event = getEventForDate(date);
    if (!event) return false;
    return capsuleNumber === 1 ? event.capsule1Taken : event.capsule2Taken;
  };

  const isBothCapsulesTaken = () => {
    const event = getEventForDate(date);
    if (!event) return false;
    return event.capsule1Taken && event.capsule2Taken;
  };

  const setReminder = () => {
    toast({
      title: t('reminderSet'),
      description: t('reminderSetDescription', { time: reminderTime }),
    });
  };

  const handleProtocolChange = (value: string) => {
    setSelectedProtocol(value);
    toast({
      title: t('protocolUpdated'),
      description: t('protocolUpdatedDescription'),
    });
  };

  const openScheduleDialog = () => {
    setIsScheduleDialogOpen(true);
  };

  const closeScheduleDialog = () => {
    setIsScheduleDialogOpen(false);
  };

  const handleScheduleIntake = (formData: ScheduleFormData) => {
    const newScheduledIntake: ScheduledIntake = {
      id: uuidv4(),
      date: formData.date,
      timeSlots: formData.timeSlots,
      notificationChannels: formData.notificationChannels,
    };

    setScheduledIntakes([...scheduledIntakes, newScheduledIntake]);
    
    toast({
      title: t('intakeScheduled'),
      description: t('intakeScheduledDescription', { 
        date: formData.date.toLocaleDateString(),
        times: formData.timeSlots.join(' & ')
      }),
    });
  };

  const deleteScheduledIntake = (scheduleId: string) => {
    setScheduledIntakes(scheduledIntakes.filter(schedule => schedule.id !== scheduleId));
    
    toast({
      title: t('scheduleDeleted'),
      description: t('scheduleDeletedDescription'),
    });
  };

  // Check if a date has a scheduled intake
  const hasScheduledIntake = (date: Date) => {
    return scheduledIntakes.some(
      schedule => schedule.date.toDateString() === date.toDateString()
    );
  };

  // Get scheduled intakes for the selected date
  const getSchedulesForDate = (date: Date) => {
    return scheduledIntakes.filter(
      schedule => schedule.date.toDateString() === date.toDateString()
    );
  };

  // Function to customize the appearance of calendar days
  const dayClassNames = (date: Date) => {
    const isScheduled = hasScheduledIntake(date);
    const event = getEventForDate(date);
    const isTakenDate = event && event.taken;
    const isPartiallyTaken = event && (event.capsule1Taken || event.capsule2Taken) && !event.taken;
    
    if (isTakenDate) {
      return "bg-green-50 text-green-600 relative rounded-full";
    }
    
    if (isPartiallyTaken) {
      return "bg-amber-50 text-amber-600 relative rounded-full";
    }
    
    if (isScheduled) {
      return "bg-blue-50 text-blue-600 relative rounded-full";
    }
    
    return "";
  };

  return (
    <div className="space-y-6">
      <Card className="glass-card overflow-hidden">
        <CardHeader className="bg-primary/5 border-b border-primary/10">
          <CardTitle>{t('usageCalendar')}</CardTitle>
          <CardDescription>
            Track your daily usage and set reminders
          </CardDescription>
        </CardHeader>
        <CardContent className="p-4 md:p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-white rounded-lg p-1 shadow-sm border">
                <Calendar 
                  mode="single" 
                  selected={date}
                  onSelect={handleDateSelect}
                  className="rounded-md pointer-events-auto"
                  modifiersClassNames={{
                    selected: "bg-primary text-primary-foreground",
                  }}
                  modifiers={{
                    customDay: (date) => 
                      events.some(event => event.date.toDateString() === date.toDateString()) ||
                      scheduledIntakes.some(schedule => schedule.date.toDateString() === date.toDateString()),
                  }}
                  modifiersStyles={{
                    customDay: { fontWeight: 'bold' }
                  }}
                  components={{
                    Day: ({ date, ...props }) => (
                      <div className={dayClassNames(date)}>
                        <button {...props} className="h-9 w-9 p-0 font-normal aria-selected:opacity-100">
                          {date.getDate()}
                          {events.some(event => 
                            event.date.toDateString() === date.toDateString() && event.taken
                          ) && (
                            <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-500 rounded-full" />
                          )}
                          {events.some(event => 
                            event.date.toDateString() === date.toDateString() && 
                            (event.capsule1Taken || event.capsule2Taken) && 
                            !event.taken
                          ) && (
                            <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-amber-500 rounded-full" />
                          )}
                          {scheduledIntakes.some(schedule => 
                            schedule.date.toDateString() === date.toDateString()
                          ) && (
                            <span className="absolute bottom-1 right-1 w-1 h-1 bg-blue-500 rounded-full" />
                          )}
                        </button>
                      </div>
                    ),
                  }}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  <span>{t('taken')}</span>
                  <span className="w-2 h-2 rounded-full bg-amber-500 ml-3"></span>
                  <span>Partially Taken</span>
                  <span className="w-2 h-2 rounded-full bg-blue-500 ml-3"></span>
                  <span>{t('scheduled')}</span>
                </div>
                <Button 
                  onClick={openScheduleDialog} 
                  variant="outline" 
                  size="sm"
                  className="gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>{t('scheduleIntake')}</span>
                </Button>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="space-y-3">
                <h3 className="text-sm font-medium">{t('selectedDate')}: {date.toLocaleDateString()}</h3>
                
                <div className="space-y-4">
                  <div className="p-4 border rounded-md bg-white shadow-sm">
                    <h4 className="text-sm font-medium mb-4">Daily Capsule Intake</h4>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-2 border rounded bg-slate-50">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="capsule1" 
                            checked={isCapsuleTaken(1)}
                            onCheckedChange={() => toggleCapsuleStatus(1)}
                            disabled={isOffCycle}
                          />
                          <label
                            htmlFor="capsule1"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Capsule 1 (First Intake)
                          </label>
                        </div>
                        <div>
                          {isCapsuleTaken(1) ? (
                            <span className="inline-flex items-center bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                              <Check className="w-3 h-3 mr-1" />
                              Taken
                            </span>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => toggleCapsuleStatus(1)}
                              disabled={isOffCycle}
                            >
                              Take Now
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between p-2 border rounded bg-slate-50">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            id="capsule2" 
                            checked={isCapsuleTaken(2)}
                            onCheckedChange={() => toggleCapsuleStatus(2)}
                            disabled={isOffCycle}
                          />
                          <label
                            htmlFor="capsule2"
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            Capsule 2 (Second Intake)
                          </label>
                        </div>
                        <div>
                          {isCapsuleTaken(2) ? (
                            <span className="inline-flex items-center bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                              <Check className="w-3 h-3 mr-1" />
                              Taken
                            </span>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => toggleCapsuleStatus(2)}
                              disabled={isOffCycle}
                            >
                              Take Now
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-3 pt-3 border-t">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Daily Status:</span>
                          <span className={`text-sm font-medium ${isBothCapsulesTaken() ? 'text-green-600' : 'text-amber-600'}`}>
                            {isBothCapsulesTaken() ? 'Completed' : 'Incomplete'}
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full mt-2 overflow-hidden">
                          <div 
                            className={`h-full ${isBothCapsulesTaken() ? 'bg-green-500' : 'bg-amber-500'}`}
                            style={{ 
                              width: isBothCapsulesTaken() 
                                ? '100%' 
                                : isCapsuleTaken(1) || isCapsuleTaken(2) 
                                  ? '50%' 
                                  : '0%' 
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                
                  {getSchedulesForDate(date).length > 0 && (
                    <div className="space-y-3">
                      {getSchedulesForDate(date).map((schedule) => (
                        <div
                          key={schedule.id}
                          className="flex items-center justify-between p-3 border rounded-md bg-blue-50/50"
                        >
                          <div>
                            <p className="font-medium">{t('scheduledIntake')}</p>
                            <div className="text-sm text-muted-foreground">
                              {t('times')}: {schedule.timeSlots.join(' & ')}
                            </div>
                            <div className="text-xs flex items-center gap-1 mt-1">
                              {schedule.notificationChannels.includes('push') && (
                                <span className="bg-slate-200 px-1.5 py-0.5 rounded">{t('pushNotification')}</span>
                              )}
                              {schedule.notificationChannels.includes('email') && (
                                <span className="bg-slate-200 px-1.5 py-0.5 rounded">{t('email')}</span>
                              )}
                              {schedule.notificationChannels.includes('whatsapp') && (
                                <span className="bg-slate-200 px-1.5 py-0.5 rounded">{t('whatsapp')}</span>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deleteScheduledIntake(schedule.id)}
                          >
                            {t('delete')}
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                
                {isOffCycle && (
                  <Alert variant="default" className="mt-2 bg-amber-50 text-amber-600 border-amber-200">
                    <AlertDescription className="flex items-center gap-2">
                      <Info className="w-4 h-4" />
                      <span>{t('offCyclePeriod', { day: (protocolDay - 30).toString(), total: '7' })}</span>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
              
              <div className="pt-6 border-t">
                <h3 className="text-sm font-medium mb-3">{t('reminders')}</h3>
                <div className="flex items-center gap-3">
                  <input 
                    type="time" 
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="rounded-md border border-input px-3 py-2 text-sm"
                  />
                  <Button onClick={setReminder} variant="outline" size="sm" className="gap-2">
                    <Bell className="w-4 h-4" />
                    <span>{t('reminders')}</span>
                  </Button>
                </div>
                
                <div className="mt-3 p-3 bg-muted/30 rounded-md">
                  <h4 className="text-sm font-medium mb-2">{t('upcomingNotifications')}</h4>
                  {scheduledIntakes.length > 0 ? (
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {scheduledIntakes
                        .filter(schedule => new Date(schedule.date) >= new Date(new Date().setHours(0, 0, 0, 0)))
                        .sort((a, b) => a.date.getTime() - b.date.getTime())
                        .slice(0, 3)
                        .map(schedule => (
                          <div key={schedule.id} className="flex justify-between text-sm p-2 bg-background rounded border">
                            <div className="flex items-center gap-2">
                              <CalendarIcon className="w-3.5 h-3.5 text-primary" />
                              <span>{schedule.date.toLocaleDateString()}</span>
                            </div>
                            <div className="text-muted-foreground">
                              {schedule.timeSlots.join(' & ')}
                            </div>
                          </div>
                        ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {t('noUpcomingNotifications')}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="pt-6 border-t">
                <h3 className="text-sm font-medium mb-3">{t('protocolSettings')}</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Clock className="text-muted-foreground w-4 h-4" />
                      <span className="text-sm">{t('cyclePattern')}</span>
                    </div>
                    <Select value={selectedProtocol} onValueChange={handleProtocolChange}>
                      <SelectTrigger className="w-[160px]">
                        <SelectValue placeholder="Select a protocol" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30-7">30 {t('day')} ON, 7 {t('day')} OFF</SelectItem>
                        <SelectItem value="60-10">60 {t('day')} ON, 10 {t('day')} OFF</SelectItem>
                        <SelectItem value="continuous">{t('continuous')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="bg-muted/50 p-3 rounded-md">
                    <div className="flex justify-between items-center text-sm">
                      <span>{t('currentProtocolDay')}:</span>
                      <span className="font-medium">{protocolDay}</span>
                    </div>
                    
                    <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${isOffCycle ? 'bg-amber-500' : 'bg-primary'}`} 
                        style={{ width: `${isOffCycle ? ((protocolDay - 30) / 7) * 100 : (protocolDay / 30) * 100}%` }}
                      ></div>
                    </div>
                    
                    <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                      <span>{t('day')} 1</span>
                      {isOffCycle ? <span>OFF {t('day')} 7</span> : <span>{t('day')} 30</span>}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-6 border-t">
                <h3 className="text-sm font-medium mb-3">{t('dailyFeedback')}</h3>
                <Button className="w-full" variant="secondary">
                  {t('submitFeedback')}
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  {t('feedbackPrompt')}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <ScheduleIntakeDialog
        isOpen={isScheduleDialogOpen}
        onClose={closeScheduleDialog}
        onSchedule={handleScheduleIntake}
        initialDate={date}
      />
    </div>
  );
};

export default UsageCalendar;
