
import React, { createContext, useState, useContext, ReactNode } from 'react';

type Language = 'en' | 'pt';

// Translation dictionary
const translations = {
  en: {
    // Common
    appName: 'NutraPulse',
    dashboard: 'Dashboard',
    settings: 'Settings',
    profile: 'Profile',
    logout: 'Logout',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    
    // Navigation
    home: 'Home',
    usage: 'Usage',
    exercises: 'Exercises',
    content: 'Content',
    progress: 'Progress',
    
    // Usage Module
    usageCalendar: 'Daily Usage Calendar',
    markAsTaken: 'Mark as Taken',
    reminders: 'Reminders',
    cycleTracker: 'Cycle Tracker',
    feedback: 'Daily Feedback',
    scheduleIntake: 'Schedule Intake',
    scheduleIntakeDescription: 'Set up your capsule intake schedule and notification preferences.',
    selectDate: 'Select Date',
    timeSlots: 'Time Slots',
    addTimeSlot: 'Add Time Slot',
    notificationChannels: 'Notification Channels',
    pushNotification: 'Push',
    email: 'Email',
    whatsapp: 'WhatsApp',
    schedule: 'Schedule',
    selectedDate: 'Selected Date',
    scheduledIntake: 'Scheduled Intake',
    times: 'Times',
    taken: 'Taken',
    scheduled: 'Scheduled',
    takeNow: 'Take Now',
    offCyclePeriod: 'You\'re currently in your off-cycle period (Day {day} of {total})',
    upcomingNotifications: 'Upcoming Notifications',
    noUpcomingNotifications: 'No upcoming notifications. Schedule an intake to receive reminders.',
    protocolSettings: 'Protocol Settings',
    cyclePattern: 'Cycle Pattern',
    currentProtocolDay: 'Current Protocol Day',
    dailyFeedback: 'Daily Feedback',
    submitFeedback: 'Submit Today\'s Feedback',
    feedbackPrompt: 'Takes just 30 seconds - help us optimize your protocol',
    reminderSet: 'Reminder set',
    reminderSetDescription: 'You\'ll be reminded daily at {time}',
    protocolUpdated: 'Protocol updated',
    protocolUpdatedDescription: 'Your protocol cycle has been updated',
    intakeScheduled: 'Intake scheduled',
    intakeScheduledDescription: 'Scheduled for {date} at {times}',
    scheduleDeleted: 'Schedule deleted',
    scheduleDeletedDescription: 'The scheduled intake has been removed',
    markedAsTaken: 'Marked as taken',
    markedAsNotTaken: 'Marked as not taken',
    usageUpdateDescription: 'You\'ve updated your usage status for {date}',
    usageRecorded: 'You\'ve recorded your supplement usage for {date}',
    day: 'Day',
    continuous: 'Continuous', // Added the missing translation key
    
    // Exercise Module
    exerciseLibrary: 'Exercise Library',
    kegel: 'Kegel Exercises',
    breathing: 'Breathing & Relaxation',
    stretching: 'Stretching & Mobility',
    challenges: 'Challenges',
    
    // Content Module
    articles: 'Articles',
    guides: 'Guides',
    relationshipTips: 'Relationship Tips',
    forum: 'Forum',
    askExpert: 'Ask an Expert',
    
    // Progress Module
    progressDashboard: 'Progress Dashboard',
    selfAssessment: 'Self Assessment',
    cycleComparison: 'Cycle Comparison',
    wellbeingScore: 'Well-being Score',
    
    // Questions
    noticeImprovement: 'Did you notice improvement?',
    sideEffects: 'Any side effects?',
    overallWellbeing: 'Overall well-being today?'
  },
  pt: {
    // Common
    appName: 'NutraPulse',
    dashboard: 'Painel Principal',
    settings: 'Configurações',
    profile: 'Perfil',
    logout: 'Sair',
    save: 'Salvar',
    cancel: 'Cancelar',
    delete: 'Excluir',
    
    // Navigation
    home: 'Início',
    usage: 'Uso',
    exercises: 'Exercícios',
    content: 'Conteúdo',
    progress: 'Progresso',
    
    // Usage Module
    usageCalendar: 'Calendário de Uso Diário',
    markAsTaken: 'Marcar como Tomado',
    reminders: 'Lembretes',
    cycleTracker: 'Rastreador de Ciclo',
    feedback: 'Feedback Diário',
    scheduleIntake: 'Agendar Ingestão',
    scheduleIntakeDescription: 'Configure seu cronograma de ingestão de cápsulas e preferências de notificação.',
    selectDate: 'Selecionar Data',
    timeSlots: 'Horários',
    addTimeSlot: 'Adicionar Horário',
    notificationChannels: 'Canais de Notificação',
    pushNotification: 'Push',
    email: 'Email',
    whatsapp: 'WhatsApp',
    schedule: 'Agendar',
    selectedDate: 'Data Selecionada',
    scheduledIntake: 'Ingestão Agendada',
    times: 'Horários',
    taken: 'Tomado',
    scheduled: 'Agendado',
    takeNow: 'Tomar Agora',
    offCyclePeriod: 'Você está atualmente no período de descanso (Dia {day} de {total})',
    upcomingNotifications: 'Notificações Próximas',
    noUpcomingNotifications: 'Sem notificações próximas. Agende uma ingestão para receber lembretes.',
    protocolSettings: 'Configurações do Protocolo',
    cyclePattern: 'Padrão de Ciclo',
    currentProtocolDay: 'Dia Atual do Protocolo',
    dailyFeedback: 'Feedback Diário',
    submitFeedback: 'Enviar Feedback de Hoje',
    feedbackPrompt: 'Leva apenas 30 segundos - ajude-nos a otimizar seu protocolo',
    reminderSet: 'Lembrete definido',
    reminderSetDescription: 'Você será lembrado diariamente às {time}',
    protocolUpdated: 'Protocolo atualizado',
    protocolUpdatedDescription: 'Seu ciclo de protocolo foi atualizado',
    intakeScheduled: 'Ingestão agendada',
    intakeScheduledDescription: 'Agendado para {date} às {times}',
    scheduleDeleted: 'Agendamento excluído',
    scheduleDeletedDescription: 'O agendamento de ingestão foi removido',
    markedAsTaken: 'Marcado como tomado',
    markedAsNotTaken: 'Marcado como não tomado',
    usageUpdateDescription: 'Você atualizou seu status de uso para {date}',
    usageRecorded: 'Você registrou o uso do suplemento para {date}',
    day: 'Dia',
    continuous: 'Contínuo', // Added the missing translation key
    
    // Exercise Module
    exerciseLibrary: 'Biblioteca de Exercícios',
    kegel: 'Exercícios de Kegel',
    breathing: 'Respiração & Relaxamento',
    stretching: 'Alongamento & Mobilidade',
    challenges: 'Desafios',
    
    // Content Module
    articles: 'Artigos',
    guides: 'Guias',
    relationshipTips: 'Dicas de Relacionamento',
    forum: 'Fórum',
    askExpert: 'Pergunte a um Especialista',
    
    // Progress Module
    progressDashboard: 'Painel de Progresso',
    selfAssessment: 'Autoavaliação',
    cycleComparison: 'Comparação de Ciclos',
    wellbeingScore: 'Pontuação de Bem-estar',
    
    // Questions
    noticeImprovement: 'Notou melhoria?',
    sideEffects: 'Algum efeito colateral?',
    overallWellbeing: 'Bem-estar geral hoje?'
  }
};

type TranslationKeys = keyof typeof translations.en;

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKeys, params?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: TranslationKeys, params?: Record<string, string | number>): string => {
    let text = translations[language][key] || key;
    
    // Replace any parameters in the translation string
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        text = text.replace(`{${paramKey}}`, paramValue.toString());
      });
    }
    
    return text;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
